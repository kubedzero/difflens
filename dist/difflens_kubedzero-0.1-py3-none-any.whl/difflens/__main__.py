from difflens import entry

# Used for running via module access, aka `python -m difflens` instead of `python -m difflens.entry`
entry.main()
