from difflens import run

# Used for running via module access, aka `python -m difflens` instead of `python -m difflens.run`
run.main()
